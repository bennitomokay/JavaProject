-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 07, 2018 at 11:17 AM
-- Server version: 5.7.19
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbemployee`
--

-- --------------------------------------------------------

--
-- Table structure for table `employeeleave`
--

DROP TABLE IF EXISTS `employeeleave`;
CREATE TABLE IF NOT EXISTS `employeeleave` (
  `empLeaveID` int(11) NOT NULL AUTO_INCREMENT,
  `empID` int(11) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Days` int(11) NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `Status` varchar(50) NOT NULL,
  PRIMARY KEY (`empLeaveID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeeleave`
--

INSERT INTO `employeeleave` (`empLeaveID`, `empID`, `Description`, `Days`, `FromDate`, `ToDate`, `Status`) VALUES
(1, 1, 'Family Responsibilty', 2, '2018-01-01', '2018-01-02', 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployee`
--

DROP TABLE IF EXISTS `tblemployee`;
CREATE TABLE IF NOT EXISTS `tblemployee` (
  `empID` int(11) NOT NULL,
  `empName` varchar(50) NOT NULL,
  `empSurname` varchar(50) NOT NULL,
  `empGender` varchar(50) NOT NULL,
  `maritulStatus` varchar(50) NOT NULL,
  `joinDate` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `Adress` varchar(50) NOT NULL,
  `contactNumber` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `SalaryScale` varchar(50) NOT NULL,
  `SpouceName` varchar(50) NOT NULL,
  `spoceContact` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployee`
--

INSERT INTO `tblemployee` (`empID`, `empName`, `empSurname`, `empGender`, `maritulStatus`, `joinDate`, `designation`, `Adress`, `contactNumber`, `email`, `SalaryScale`, `SpouceName`, `spoceContact`) VALUES
(1, 'Benny', 'Mogale', 'Male', 'Single', '25/10/2015', 'Manager', '10227 Ingwenya Str', '0769442639', 'bennito.mokay@gmail.com', '2', '', ''),
(2, 'Sipho', 'Mogale', 'Male', 'Single', '2018/01/12', 'Programmer', '10227 Ingwenya', '076885421', 'Sipho', 'm.bernad@yahoo.com', 'none', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `tblleave`
--

DROP TABLE IF EXISTS `tblleave`;
CREATE TABLE IF NOT EXISTS `tblleave` (
  `LeaveID` int(11) NOT NULL,
  `Description` varchar(50) NOT NULL,
  `Days` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `UserName` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  PRIMARY KEY (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`userID`, `UserName`, `Password`) VALUES
(1, 'benny', '123'),
(2, 'sipho', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
