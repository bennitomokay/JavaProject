/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author karabo
 */
public class Employee {
    
    private int empID;
    private String empName;
    private String empSurname;
    private String empGender;
    private String maritulStatus;
    private String joinDate;
    private String designation;
    private String Adress;
    private String contactNumber;
    private String email;
    private String SalaryScale;
    private String SpouceName;
    private String spoceContact;

    public int getEmpID() {
        return empID;
    }

    public String getEmpName() {
        return empName;
    }

    public String getEmpSurname() {
        return empSurname;
    }

    public String getEmpGender() {
        return empGender;
    }

    public String getMaritulStatus() {
        return maritulStatus;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public String getDesignation() {
        return designation;
    }

    public String getAdress() {
        return Adress;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public String getSalaryScale() {
        return SalaryScale;
    }

    public String getSpouceName() {
        return SpouceName;
    }

    public String getSpoceContact() {
        return spoceContact;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public void setEmpSurname(String empSurname) {
        this.empSurname = empSurname;
    }

    public void setEmpGender(String empGender) {
        this.empGender = empGender;
    }

    public void setMaritulStatus(String maritulStatus) {
        this.maritulStatus = maritulStatus;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public void setAdress(String Adress) {
        this.Adress = Adress;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setSalaryScale(String SalaryScale) {
        this.SalaryScale = SalaryScale;
    }

    public void setSpouceName(String SpouceName) {
        this.SpouceName = SpouceName;
    }

    public void setSpoceContact(String spoceContact) {
        this.spoceContact = spoceContact;
    }

    public Employee(int empID, String empName, String empSurname, String empGender, String maritulStatus, String joinDate, String designation, String Adress, String contactNumber, String email, String SalaryScale, String SpouceName, String spoceContact) {
        this.empID = empID;
        this.empName = empName;
        this.empSurname = empSurname;
        this.empGender = empGender;
        this.maritulStatus = maritulStatus;
        this.joinDate = joinDate;
        this.designation = designation;
        this.Adress = Adress;
        this.contactNumber = contactNumber;
        this.email = email;
        this.SalaryScale = SalaryScale;
        this.SpouceName = SpouceName;
        this.spoceContact = spoceContact;
    }
    
    
    
    
    
    
    
}
