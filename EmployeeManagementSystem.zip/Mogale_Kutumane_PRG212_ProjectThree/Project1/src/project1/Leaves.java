/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author karabo
 */
public class Leaves {
    
    private String description;
    private int days;

    public String getDescription() {
        return description;
    }

    public int getDays() {
        return days;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public Leaves(String description, int days) {
        this.description = description;
        this.days = days;
    }
    
    
    
}
