/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.DriverManager;
import javax.swing.JOptionPane;
import java.*;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class ViewEmployee extends javax.swing.JFrame {

  Connection con = null;
  ResultSet rs = null;
  Statement st = null;
  
  
    public ViewEmployee() {
        initComponents();
        Display();
    }
    
    public ArrayList<Employee> EmployeeList(){
         ArrayList<Employee> emp = new ArrayList<Employee>();
         try{
             
             con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbEmployee",
                     "root", "");
             String query = "SELECT * FROM tblEmployee";
             st = con.createStatement();
             rs = st.executeQuery(query);
             
             Employee em;
             
             while(rs.next()){
                 em = new Employee(rs.getInt("empID"), rs.getString("empName"),
                         rs.getString("empSurname"), rs.getString("empGender"),
                         rs.getString("maritulStatus"),rs.getString("joinDate"),
                         rs.getString("designation"), rs.getString("Adress"),
                         rs.getString("contactNumber"), rs.getString("email"), 
                         rs.getString("SalaryScale"), rs.getString("SpouceName"),
                         rs.getString("spoceContact"));
                 emp.add(em);
             }
             
         }
         catch(Exception e){
             JOptionPane.showMessageDialog(null, e);
         }
         
         
         return emp;
         
        
    }
    
        public void Display(){
        
        ArrayList<Employee> list = EmployeeList();
        DefaultTableModel model = (DefaultTableModel)tblEmployees.getModel();
        Object[] rows = new Object[4];
        for (int i = 0; i < list.size(); i++) {
            
            rows[0] =list.get(i).getEmpID();
            rows[1] = list.get(i).getEmpName();
            rows[2] = list.get(i).getEmpSurname();
            rows[3] = list.get(i).getEmpGender();
            rows[3] = list.get(i).getMaritulStatus();
            rows[3] = list.get(i).getJoinDate();
            rows[3] = list.get(i).getDesignation();
            rows[3] = list.get(i).getAdress();
            rows[3] = list.get(i).getContactNumber();
            rows[3] = list.get(i).getEmail();
            rows[3] = list.get(i).getSalaryScale();
            rows[3] = list.get(i).getSpouceName();
            rows[3] = list.get(i).getSpoceContact();
            
            model.addRow(rows);
        }
        
        
        
        
        
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblEmployees = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        tblEmployees.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Name", "Surname", "Gender", "Maritul Status", "Join Date", "Designation", "Address", "Contact Number", "email", "Salary Scale", "Spouce Name", "Spouce Number"
            }
        ));
        jScrollPane1.setViewportView(tblEmployees);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 846, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(69, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewEmployee.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewEmployee().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblEmployees;
    // End of variables declaration//GEN-END:variables
}
