/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

/**
 *
 * @author karabo
 */
public class LeaveApplicationC {
    
    private int empLeaveID;
    private int empID;
    private int days;
    private String leaveDescription;
    private String FromDate;
    private String ToDate;
    private String Status;

    public int getEmpLeaveID() {
        return empLeaveID;
    }

    public int getEmpID() {
        return empID;
    }

    public int getDays() {
        return days;
    }

    public String getLeaveDescription() {
        return leaveDescription;
    }

    public String getFromDate() {
        return FromDate;
    }

    public String getToDate() {
        return ToDate;
    }

    public String getStatus() {
        return Status;
    }

    public void setEmpLeaveID(int empLeaveID) {
        this.empLeaveID = empLeaveID;
    }

    public void setEmpID(int empID) {
        this.empID = empID;
    }

    public void setDays(int days) {
        this.days = days;
    }

    public void setLeaveDescription(String leaveDescription) {
        this.leaveDescription = leaveDescription;
    }

    public void setFromDate(String FromDate) {
        this.FromDate = FromDate;
    }

    public void setToDate(String ToDate) {
        this.ToDate = ToDate;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }

    public LeaveApplicationC(int empLeaveID, int empID, int days, String leaveDescription, String FromDate, String ToDate, String Status) {
        this.empLeaveID = empLeaveID;
        this.empID = empID;
        this.days = days;
        this.leaveDescription = leaveDescription;
        this.FromDate = FromDate;
        this.ToDate = ToDate;
        this.Status = Status;
    }
    
    
    
    


    
    
    
    
    
}
